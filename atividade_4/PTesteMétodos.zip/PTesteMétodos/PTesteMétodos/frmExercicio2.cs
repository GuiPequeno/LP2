﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMétodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnComparar_Click(object sender, EventArgs e)
        {
            if (String.Compare(txtPalavra1.Text, txtPalavra2.Text) == 0) 
            {
                MessageBox.Show("As palavras digitadas são iguais");   
            }

            else 
            {
                MessageBox.Show("As palavras digitadas são diferentes");
            }
        }

        private void btnInserir1_Click(object sender, EventArgs e)
        {
            int Palavra1_Meio = txtPalavra1.TextLength / 2;
            string parte1 = txtPalavra1.Text.Substring(0, Palavra1_Meio);
            string parte2 = txtPalavra1.Text.Substring(Palavra1_Meio);
            string Mensagem = parte1 + txtPalavra2.Text + parte2;
            MessageBox.Show(Mensagem);
        }

        private void btnInserir2_Click(object sender, EventArgs e)
        {
            int Palavra1_Meio = txtPalavra1.TextLength / 2;
            string parte1 = txtPalavra1.Text.Substring(0, Palavra1_Meio);
            string parte2 = txtPalavra1.Text.Substring(Palavra1_Meio);
            string Mensagem = parte1 + "**" + parte2;
            MessageBox.Show(Mensagem);
        }
    }
}
