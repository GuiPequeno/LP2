﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        private void mskPesoAtual_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskPesoAtual.Text, out peso))
            {
                MessageBox.Show("Peso inválido");
                mskPesoAtual.Focus();
            }
        }

        private void mskAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskAltura.Text, out altura))
            {
                MessageBox.Show("Altura inválida");
                mskAltura.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskAltura.Clear();
            mskPesoAtual.Clear();
            txtIMC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            imc = peso / (altura * altura);
            imc = Math.Round(imc,1);
            txtIMC.Text = imc.ToString("n1");

            if (imc < 18.5)
            {
                MessageBox.Show("MAGREZA");
            }

            else if(imc <= 24.9)
            {
                MessageBox.Show("NORMAL");
            }

            else if(imc <= 29.9)
            {
                MessageBox.Show("SOBREPESO");
            }

            else if(imc <= 39.9)
            {
                MessageBox.Show("OBESIDADE");
            }

            else{
                MessageBox.Show("OBESIDADE GRAVE");
            }
        }

    }
}
