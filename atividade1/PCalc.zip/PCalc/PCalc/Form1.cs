﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {

        double Numero1, Numero2, Resultado;
        public Form1()
        {
            InitializeComponent();
          
        }


        private void btnSomar_Click(object sender, EventArgs e)
        {
            Resultado = Numero1 + Numero2;
            txtResultado.Text = Resultado.ToString();

        }


        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
  
        }
        private void btnDividir_Click(object sender, EventArgs e)
        {
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
            txtNumero1.Focus();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            if(this.ActiveControl == btnSair)
            {
                return;
            }

            if (!double.TryParse(txtNumero2.Text, out Numero2))
            {
                MessageBox.Show("Numero 2 inválido");
                txtNumero2.Focus();
            }
        }

        private void btnSubtrair_Click_1(object sender, EventArgs e)
        {
            Resultado = Numero1 - Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnMultiplicar_Click_1(object sender, EventArgs e)
        {
            Resultado = Numero1 * Numero2;
            txtResultado.Text = Resultado.ToString();
        }

        private void btnDividir_Click_1(object sender, EventArgs e)
        {
            Resultado = Numero1 / Numero2;
            txtResultado.Text = Resultado.ToString();

            if (Numero1 ==0 ||  Numero2 == 0)
            {
                MessageBox.Show("Não pode dividir por zero!");
                txtNumero1.Focus();
            }
        }

        private void btnLimpar_Click_1(object sender, EventArgs e)
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            txtResultado.Clear();
            txtNumero1.Focus();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (this.ActiveControl == btnSair)
            {
                return;
            }

            if (!double.TryParse(txtNumero1.Text, out Numero1))
            {
                MessageBox.Show("Numero 1 inválido");
                txtNumero1.Focus();
            }
        }

    }
}
